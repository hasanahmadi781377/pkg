from pkg.get_request import get_value


__all__ = ['get_value']