from setuptools import setup
setup(
    name='pkg',
    version='0.1',
    description='this is for the test demo',
    url='#',
    author='Hasan ahmadi',
    author_email='hasanahmadi781377@gmail.com',
    license='MIT',
    packages=['pkg'],
    zip_safe=False)