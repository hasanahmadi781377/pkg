from setuptools import setup
setup(
    name='pkg',
    version='1.2',
    description='this is for the test demo',
    url='https://github.com/hasanahmadi781377/pkg',
    author='Hasan ahmadi',
    author_email='hasanahmadi781377@gmail.com',
    license='MIT',
    packages=['pkg'],
    install_requires=['Django'],
    zip_safe=False)